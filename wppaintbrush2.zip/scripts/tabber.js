var $ = jQuery;
$(function() {
	$("#tabs").tabs();
	//$('#tabs').tabs({ fxFade: true, fxSpeed: 'slow' });
	//$('#tabs').tabs({ fxSlide: true });
});
