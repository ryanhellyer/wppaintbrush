<?php
/**
 * Template Name: Page template 2
 *
 * @package WordPress
 * @subpackage WP Paintbrush theme
 * @since WP Paintbrush 0.2
 *
 * This file is needed so that the template appears in WordPress admin panel
 */



get_template_part( 'index');

