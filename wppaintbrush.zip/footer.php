<?php
/**
 * @package WordPress
 * @subpackage WP Paintbrush
 * @since WP Paintbrush 0.1
 */
?>

<?php wp_footer(); ?>
</body>
</html>