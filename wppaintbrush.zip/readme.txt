=== WP Paintbrush ===
Contributors: Ryan Hellyer
Donate link: http://wppaintbrush.com/plugins/
Tags: dark, light, white, black, gray, red, orange, yellow, green, blue, purple, one-column, two-columns, three-columns, left-sidebar, right-sidebar, fixed-width, flexible-width, custom-background, custom-colors, custom-header, custom-menu, featured-image-header, featured-images, full-width-template, theme-options, translation-ready
Requires at least: 3.3
Tested up to: 3.3
Stable tag: 1.0.3

The file is a work in progres ... WP Paintbrush provides an easy to use wysiwyg editing tool for redesigning your site.

== Description ==

WP Paintbrush provides an easy to use wysiwyg editing tool for redesigning your site.

== Installation ==

1. Upload the `wppaintbrush` folder to the `/wp-content/themes/` directory
2. Activate the Theme through the 'Themes' menu in WordPress
3. Head to the front-end of the site to use the wysiwyg editor tool

== Theme Notes ==

== Frequently Asked Questions ==

= Can I extend WP Paintbrush? =

Yes, plugins for WP Paintbrush are available at http://wppaintbrush.com/plugins/

== Screenshots ==

1. Front-end editor

== Changelog ==

= 1.0.3 [20/10/2011] =
* Added support for Magazine layouts via hooks and extra code
* Performance enhancement via improved use of data sanitization
* Minor code improvements
* Minor bug fixes

= 1.0.2 [05/10/2011] =
* Added readme.txt file (which you are reading right now!)
* Changed references to 'ptc' to 'wppb'. 'ptc' was a reference to the code name "PixoPoint Theme Creator" which was used during the very early alpha builds
* Changed ptc_load_css() to wppb_load_processed_css()
* Removed references to comments_template() and add_editor_style() from functions.php as they are already in use in shortcodes.php file

= 1.0.1 [05/10/2011] =
* Added auto-updating support

== Upgrade Notice ==

= 1.0.2 =
Maintenance release. Minor updates only.
